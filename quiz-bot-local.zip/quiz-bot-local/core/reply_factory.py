
from .constants import BOT_WELCOME_MESSAGE, PYTHON_QUESTION_LIST


def generate_bot_responses(message, session):
    bot_responses = []

    current_question_id = session.get("current_question_id")
    if not current_question_id:
        bot_responses.append(BOT_WELCOME_MESSAGE)

    success, error = record_current_answer(message, current_question_id, session)

    if not success:
        return [error]

    next_question, next_question_id = get_next_question(current_question_id)

    if next_question:
        bot_responses.append(next_question)
    else:
        final_response = generate_final_response(session)
        bot_responses.append(final_response)

    session["current_question_id"] = next_question_id
    session.save()

    return bot_responses


def record_current_answer(answer, current_question_id, session):
    # Ensure that the session has an 'answers' dictionary initialized
    if 'answers' not in session:
        session['answers'] = {}

    # Retrieve the question from the question list using the question id
    current_question = PYTHON_QUESTION_LIST.get(current_question_id)

    # Check if the current question exists
    if current_question:
        # Validate the answer based on the question's requirements
        if validate_answer(answer, current_question):
            # If the answer is valid, store it in the session
            session["answers"][current_question_id] = answer
            return True, ""
        else:
            # If the answer is not valid, return an error message
            error_message = "Invalid answer. Please provide a valid response."
            return False, error_message
    else:
        # If the question doesn't exist, return an error message
        error_message = "Current question not found."
        return False, error_message


def validate_answer(answer, question):
    '''
    Validates the answer based on the question's requirements.
    This is a placeholder function and should be replaced with actual validation logic.
    '''
    # Placeholder validation logic
    # Here you can implement your specific validation logic based on the question
    # For example, you can check if the answer is of the correct data type or within a certain range
    # For demonstration purposes, this function always returns True
    return True,


def get_next_question(current_question_id):
    '''
    Fetches the next question from the PYTHON_QUESTION_LIST based on the current_question_id.
    '''

    # Get the index of the current question
    current_question_index = PYTHON_QUESTION_LIST.index(current_question_id)

    # Check if there are more questions in the list
    if current_question_index + 1 < len(PYTHON_QUESTION_LIST):
        # If there are more questions, return the next question and its id
        next_question_id = PYTHON_QUESTION_LIST[current_question_index + 1]
        next_question = PYTHON_QUESTION_LIST[next_question_id]
        return next_question, next_question_id
    else:
        # If there are no more questions, return None
        return None, None


def generate_final_response(session):
    '''
    Creates a final result message including a score based on the answers
    by the user for questions in the PYTHON_QUESTION_LIST.
    '''

    # Get the user's answers from the session
    user_answers = session.get("answers", {})

    # Initialize variables to calculate the score
    total_questions = len(PYTHON_QUESTION_LIST)
    correct_answers = 0

    # Iterate through each question in the PYTHON_QUESTION_LIST
    for question_id, correct_answer in PYTHON_QUESTION_LIST.items():
        # Check if the user provided an answer for the question
        if question_id in user_answers:
            user_answer = user_answers[question_id]
            # Check if the user's answer matches the correct answer
            if user_answer == correct_answer:
                correct_answers += 1

    # Calculate the score percentage
    score_percentage = (correct_answers / total_questions) * 100

    # Generate the final result message
    final_result_message = f"Congratulations! You have completed the quiz.\n"\
                           f"Total questions: {total_questions}\n"\
                           f"Correct answers: {correct_answers}\n"\
                           f"Score: {score_percentage:.2f}%"

    return final_result_message
